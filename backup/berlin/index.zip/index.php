<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->

<title>Это Мозгва детка!</title>
<link rel="stylesheet" href="css/960.css" />
<link rel="stylesheet" href="css/owl.carousel.css" />
<link rel="stylesheet" href="css/styles.css" />
<link rel="stylesheet" href="css/main.css" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

<meta property="og:title" content="Это Мозгва детка!" />
      <meta property="og:description" content="Интеллектуальная бар-олимпиада Мозгва – это серия мероприятий, созданная для активного использования ума. " />
      <meta property="og:url" content="http://mozgva.ru/" />
      <meta property="og:image" content="http://mozgva.ru/img/logog.png" />

      <meta name="title" content="Это Мозгва детка!" />
      <meta name="description" content="Интеллектуальная бар-олимпиада Мозгва – это серия мероприятий, созданная для активного использования ума." />
      <link rel="image_src" href="http://mozgva.ru/img/logog.png" />

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>

<meta name="google-site-verification" content="zTQ1gDIWkIzExf_Q149SulTC9T5fXnvbkgAPb9EvB5k" />
<!--[if IE]>
	<link href="css/styles-ie.css" rel="stylesheet" type="text/css" />
<![endif]-->

<!--[if lt IE 9]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<!--[if (gte IE 5.5)&(lte IE 8)]>
	<script type="text/javascript" src="js/selectivizr.js"></script>
<![endif]-->

<!--[if lte IE 6]>
	<meta http-equiv="refresh" content="0; url=http://yoursite.com/ie6/ie6.html"> 	
<![endif]-->
</head>
<body>
	<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter30751938 = new Ya.Metrika({id:30751938,
                    webvisor:true,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true});
        } catch(e) { }
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/30751938" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
	<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-N3R5QZ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N3R5QZ');</script>
<!-- End Google Tag Manager -->

<?php 
function russian_date(){
	$date=explode(".", date("d.m.Y"));
	switch ($date[1]){
		case 1: $m='января'; break;
		case 2: $m='февраля'; break;
		case 3: $m='марта'; break;
		case 4: $m='апреля'; break;
		case 5: $m='мая'; break;
		case 6: $m='июня'; break;
		case 7: $m='июля'; break;
		case 8: $m='августа'; break;
		case 9: $m='сентября'; break;
		case 10: $m='октября'; break;
		case 11: $m='ноября'; break;
		case 12: $m='декабря'; break;
	}
	echo $date[0].'&nbsp;'.$m;
}
?>
<!-- =start -->
<section class="start">
	<div class="container">
		<div class="wrap">
			<div class="date">
				<!-- <p id="date2">Время: 20:00 <span class="cash">9, 10, 11, 12 ноября</span> </p> 
				<p id="date2">Время: 16:00 <span class="cash">3 октября (суббота!)</span> </p> -->
				<span>Вход: 500 <i class="fa fa-rub"></i> <span class="cash">(только наличные) Время: 20:00 <!-- 4-6 января, 7-9 января --></span></span>
				<div class="place">
					<a href="http://coin-hall.ru/" target="_blank" title="">
						Кафе-бар <br>
							«Coin hall» </a> (2-3<!-- , 6, 11 --> февраля)
							</br>6 февраля - начало в 16.00
						
					
				</div><!--
				<div class="place">
					<a href="http://darlingbars.ru/" target="_blank" title="">
						Кафе-бар<br>
						<span>«Дорогая, я перезвоню» (27 октября)</span>
					</a>
				</div> -->

			</div>
			<div class="logo">
				<img src="images/logo.svg" width="200" alt="">
			</div>
			<div class="stat">
				Идет <span>490</span> человек<br>
				<div id="soc">
					<a href="https://www.facebook.com/etomozgvadetka" target="_blank"><i class="fa fa-facebook-official"></i></a>
					<a href="http://vk.com/etomozgvadetka" target="_blank"><i class="fa fa-vk"></i></a>
					<a href="https://www.instagram.com/mozgva_msk/" target="_blank"><i class="fa fa-instagram"></i></a>
				</div>
			</div>
		</div>

		<div class="container_16 mozgva">
			<!-- <p class="1213">Важно!!! Регистрация открыта только на пятницу!</p> -->
			<div class="grid_14 text-center info">
				<p>Это Мозгва,<br>детка!</p>
				<!-- <p><span class="cash">Регистрация закрыта, мест нет</span></p>-->
				<a href="#" title="" class="grid_4 signin">Участвовать</a> 
			</div>
			
		</div>
		<div class="like">
				<div class="share pull-left">
					<script type="text/javascript" src="//yastatic.net/share/share.js" charset="utf-8"></script><div data-url="http://mozgva.ru" data-title="Это Мозгва детка!" data-description="Интеллектуальная бар-олимпиада Мозгва – это серия мероприятий, созданная для активного использования ума." class="yashare-auto-init" data-yashareL10n="ru" data-yashareType="big" data-yashareQuickServices="facebook,vkontakte" data-yashareTheme="counter"></div>						
				</div>
				<img src="images/like.png" alt="" class="pull-right" />
			</div>
		<div class="like2">
			<a target="_blank" href="https://www.facebook.com/duetris/"><img src="images/RiS_Logo_main.png" width="80px" alt=""  /></a> <p id="fff"><a target="_blank" href="https://www.facebook.com/duetris/">Дуэт<br /> ведущих</a><br /><br /><br /></p>
			<img src="images/logo.png" alt=""  />
			<p>Крупнейшие игровые <br> центры квестов <br><br> <a id="link" target="_blank" href="https://exitgames.ru/">exitgames.ru</a></p>
			<style type="text/css">
				.like2 a {
				    color: white;
					}
			</style>

		</div>	
	</div>
</section>
<!-- =/start -->
<!-- pokupki -->
<section class="sell">
	<div class="container_16">
		<div class="grid_8 sell_left">
			<img src="images/sert.png" alt=""></div>
		<div class="grid_8 sell_right">
			<h1>Дарите <br> Мозгву!</h1>
			<p>Забудьте про цветы. У нас можно купить подарочные сертификаты на 3-х, 6-х и 9-х участников. Забрать сертификаты можно на одной из игр или у нас в офисе в р-не Третьяковской</p>
			<ul>
				<li>
					<p>3-x</p>
					<p class="red_text">1500 р.</p>
				</li>
				<li>
					<p>6-x</p>
					<p class="red_text">3000 р.</p>
				</li>
				<li>
					<p>9-x</p>
					<p class="red_text">4500 р.</p>
				</li>
			</ul>
			<p><a href="#" class="red_btn">Заказать сертификат</a></p>
		</div>
	</div>
	
</section>
<!-- /pokupki -->
<!-- =whatis -->
<section class="whatis">
	<header>
		<h1>Интеллектуальная <br>бар-олимпиада</h1>
		<h2>Это Мозгва, добро пожаловать!</h2>
	</header>
	<div class="container_16">
			<div class="cell">
	Интеллектуальная бар-олимпиада Мозгва – это серия мероприятий, созданная для активного использования ума. Здесь собираются те, кому хочется держать мозг в тонусе и соревноваться с другими бодрыми и уверенными в себе интеллигентами и пролетариями 21-го века.			
			</div>
			<div class="cell">
	Самое приятное в Мозгве – это быть вместе друзьями. Именно с ними, самыми близкими товарищами, Вы плечом к плечу сможете побеждать или с гордо поднятой головой откладывать победу до следующей схватки.		
			</div>
			<div class="cell">
	Каждый вечер, когда Мозгва открывает свои двери, у Вас есть возможность провести время в буре здорового азарта и доказать, что голова нужна не только для того, чтобы загружать в нее пищу.
			</div>
		</div>
	
</section>
<!-- =/whatis -->

<!-- intellect -->
<section class="intellect">
	<div class="wrapper">
		<header>
			<h1>Интел-<br/>лектуаль-<br/>ная</h1>
		</header>
		<div class="carousel pull-right">
			<div class="owl-carousel" id="intellect">
				<div class="item">
					<p class="title">Тур 1: <span>Эхо Мозгвы (Горячие новости)</span></p>
					<div>На днях в аэропорт Бордо поступил звонок с сообщением о заложенной взрывчатке. Полиция провела полный осмотр всех помещений, угрозы для безопасности не обнаружила. Отследив вызов, выяснили, что звонок сделали в радиусе 19 км от аэропорта. Очень быстро мужчину нашли и арестовали. <span>Зачем он это сделал?</span></div>
					<div class="answer reflection">(Думай своей головой)</div>
				</div>
				<div class="item">
					<p class="title">Тур 2: <span>Fuckts (Интересные факты)</span></p>
					<div>В Париже находится одна примечательная улица – авеню генерала Лемонье. В чем заключается исключительность этой улицы для всей континентальной Европы?</div>
					<div class="answer reflection">(Думай своей головой)</div>
				</div>
				<div class="item">
					<p class="title">Тур 3: <span>Шоу Мозгоу ON (Музыкальный тур)</span></p>
					<div>Чей это голос?<br><iframe width="420" height="315" src="https://www.youtube.com/embed/SKEpT_GIgCk" frameborder="0" allowfullscreen></iframe></div>
					<div class="answer reflection">(Думай своей головой)</div>
				</div>
				<div class="item">
					<p class="title">Тур 4: <span>Москва за 300 (Места, события и люди Москвы)</span></p>
					<div>В каком аэропорту Москвы произошел исторический поцелуй Брежнева и Хонеккера в 1971 году. <br /><br /><img width="300" src="img/1971.png"></div>
					<div class="answer reflection">(Думай своей головой)</div>
				</div>
				<div class="item">
					<p class="title">Тур 5: <span>Поп-корн (Индустрия большого экрана)</span></p>
					<div>Кто на фото?<br><br> <img width="250" src="img/6q.png"></div>
					<div class="answer reflection">(Думай своей головой)</div>
				</div>
				<div class="item">
					<p class="title">Тур 6: <span>Гуманитарии недоумевают (Вопросы из области негуманитарных наук)</span></p>
					<div>Какое устройство заменило человека с очень редкой профессией?<br><br> <img width="300" src="img/5q.png"></div>
					<div class="answer reflection">(Думай своей головой)</div>
				</div>
				<div class="item">
					<p class="title">Тур 7: <span>Мозгва Культурная (Культура – наше всё)</span></p>
					<div>В древнегреческом театре был особый ряд для воинов, потерявших в бою руку. Перед однорукими ветеранами сажали лысых рабов. Для чего греки это делали?</div>
					<div class="answer reflection">(Думай своей головой)</div>
				</div>								
			</div>
		</div>
	</div>
	<div class="container_16">
		<div class="grid_7 text">
			<p>У разума нет границ. Да и объективных единиц его исчисления пока не придумано. Но мы постарались заключить различные виды знаний, логические задачи и задания на сообразительность в необычные вопросы. Просто для того, чтобы все, кто любит пользоваться мозгом, смогли помериться интеллектами с голодными до умственных баталий соперниками.</p>
		</div>
	</div>
</section>
<!-- /intellect -->

<!-- =bar -->
<section class="bar">
	<div class="wrapper">
		<img src="images/quote.png" alt="" class="quote" />
	</div>
	<div class="container_16">
		<div class="grid_7 prefix_9 text">
			<header>
				<h1>Бар-</h1>
			</header>
			<p>Почти всегда турниры будут проводиться в барах, ресторанах, поскольку здесь можно не только уютно провести время с друзьями, отвечая на захватывающие вопросы. Специально для мозгвичей, приходящих на игру после рабочего дня, будет подготовлено отдельное меню на ужин по действительно невероятной цене.</p>
		</div>
	</div>	
</section>
<!-- =/bar -->


<!-- =olympiada -->
<section class="olympiada">
	<div class="wrapper">
		<header>
			<h1>Олим-<br/>пиада</h1>
		</header>
		<div class="container_16">
			<div class="grid_7 text">
				<p>Чтобы все участники были в более или менее равных условиях, мы разработали четкий формат соревнований. Он никогда не меняется и позволяет говорить об объективности во время определения победителя. Именно регламент добавляет азарта и делает наши веселые вечера по-настоящему спортивными!</p>
				
			</div>
		</div>	
		<div class="container_block">
				<div class="block">
				<div class="colv">2-9</div>
				
				<div class="texts">Количество участников в команде</div>
				</div>
				<div class="block">
				<div class="colv">39</div>
				
				<div class="texts">Количество вопросов<br>(7 туров, 39 вопросов)</div>
				</div>
				<div class="block">
				<div class="colv">69<span>сек</span></div>
				
				<div class="texts">Время на ответ</div>
				</div>
				<div class="block">
				<div class="colv">2,5<span>часа</span></div>
				
				<div class="texts">Длительность игры</div>
				</div>
				<div class="block">
				<div class="colv">2</div>
				
				<div class="texts">Длинных перерыва</div>
				</div>
				</div>
	</div>
</section>
<!-- =/olympiada -->
<!-- =kontakts -->
<section class="kontakts">
	<div class="wrapper">
		<div id="soc">
					<a href="https://www.facebook.com/etomozgvadetka" target="_blank"><i class="fa fa-facebook-official"></i></a>
					<a href="http://vk.com/etomozgvadetka" target="_blank"><i class="fa fa-vk"></i></a>
					<a href="https://www.instagram.com/mozgva_msk/" target="_blank"><i class="fa fa-instagram"></i></a>
				</div>
		
		<div class="container_16">
			<div class="grid_7 text">
				<p>Вход: 500 <i class="fa fa-rub"></i><br>+7 495 644-52-72<br>government@mozgva.ru<br><br>	</p>
				<p>Организация частных мероприятий: <br />+7 926 608-25-41<br />pavlinsky@mozgva.ru<br /></p><br /><br />


			</div>
		</div>	
	</div>
</section>
<!-- =/kontakts -->

<script>
function func() {
    $.get("https://userarea.sms-assistent.by/api/v1/send_sms/plain?user=Iksboks&password=cS6888b5&recipient="+$('input.required').val()+"&message=Команда "+$('input.team').val()+" "+$('input.quantity').val()+" человек зарегистрирована на Мозгву "+ $('input:checked').val()+" Ждем Вас!&sender=MOZGVA");
   }
</script>

<div id="reg" class="jqmWindow text-center">
	<a href="#" class="jqmClose" title=""><img src="images/close.png" alt="" /></a>
	<form action="https://docs.google.com/forms/d/1w1NNRlYgISNEHOyYYv2yV5gYLcfrZMFLbogtTzzaLXA/formResponse" method="post" class="text-center" id="form1" onsubmit='func();'>
		<fieldset>
			<p class="title">Регистрация  в Мозгве</p>
			<p>Мы очень рады, что Вы к нам присоединяетесь, будет действительно круто!</p>
			<p>Обещаем, что Ваши контактные данные будем использовать только для того, чтобы быть на связи перед игрой, на которую Вы регистрируетесь!</p>
			<br/>
			<p>Дорогие друзья, напоминаем:<br>
			Вас ожидают серьезные призы и замечательные подарки, поэтому вход 500р.</p>
			<div class="row">
				<div class="column pull-left">
					<input type="text" name="entry_751817998" class="captain" value="" placeholder="Имя капитана" />
					<input type="text" name="entry.1622386422" class="team" value="" placeholder="Название команды" />				
					<input type="text" name="entry.1926264121" class="quantity" value="" placeholder="Количество человек" />
					<input type="text" name="entry.1250708141" form="form1" class="required" pattern="[\+][7]\d{10}"  placeholder="Телефон" />				
				</div>
				<div class="column pull-right">
					<input type="text" name="entry.191141737" class="" value="" placeholder="Имя боцмана" />				
					<input type="text" name="entry.307300218" class="required" pattern="[\+][7]\d{10}" value="" placeholder="Телефон" />	
					<input type="text" name="entry.1094067227" class="" value="" placeholder="Кто пригласил Вас на Мозгву?" />
				</div>
			</div>


<!-- Выбор дня -->

<br>
<div class="ss-form-entry">
<label class="ss-q-item-label" for="entry_1000067181"><div class="ss-q-title">Какой день?
<label for="itemView.getDomIdToLabel()" aria-label="Обязательное поле"></label>
<span class="ss-required-asterisk" aria-hidden="true">*</span></div>
<div class="ss-q-help ss-secondary-text" dir="auto"></div></label>


<ul class="ss-choices" role="radiogroup" aria-label="Какой день?  ">

	<li class="ss-choice-item"><label><span class="ss-choice-item-control goog-inline-block"><input type="radio" name="entry.1125742307" value="02.02.2016" id="group_1125742307_1" role="radio" class="ss-q-radio" aria-label="02.02.2016" required="" aria-required="true"></span>
<span class="ss-choice-label">02 февраял (Вторник)</span>
</label></li> <li class="ss-choice-item"><label><span class="ss-choice-item-control goog-inline-block"><input type="radio" name="entry.1125742307" value="03.02.2016" id="group_1125742307_2" role="radio" class="ss-q-radio" aria-label="03.02.2016" required="" aria-required="true"></span>
<span class="ss-choice-label">03 февраля (Среда)</span>
</label></li> 

<!-- <li class="ss-choice-item"><label><span class="ss-choice-item-control goog-inline-block"><input type="radio" name="entry.1125742307" value="05.02.2016" id="group_1125742307_3" role="radio" class="ss-q-radio" aria-label="05.02.2016" required="" aria-required="true"></span>
<span class="ss-choice-label">05 февраля (Пятница)</span> 
</label></li> -->

<!--
<li class="ss-choice-item"><label><span class="ss-choice-item-control goog-inline-block"><input type="radio" name="entry.1125742307" value="06.02.2016" id="group_1125742307_4" role="radio" class="ss-q-radio" aria-label="06.02.2016" required="" aria-required="true"></span>
<span class="ss-choice-label">06 февраля (Суббота - 16:00)</span>
</label></li> <li class="ss-choice-item"><label><span class="ss-choice-item-control goog-inline-block"><input type="radio" name="entry.1125742307" value="11.02.2016" id="group_1125742307_5" role="radio" class="ss-q-radio" aria-label="11.02.2016" required="" aria-required="true"></span>
<span class="ss-choice-label">11 февраля (Четверг)</span>
</label></li> 
-->

<!-- <li class="ss-choice-item"><label><span class="ss-choice-item-control goog-inline-block"><input type="radio" name="entry.1125742307" value="12.02.2016" id="group_1125742307_6" role="radio" class="ss-q-radio" aria-label="12.02.2016" required="" aria-required="true"></span>
<span class="ss-choice-label">12 февраля (Пятница)</span>
</label></li> -->

</ul>


<div class="error-message" id="1000067181_errorMessage"></div>
<div class="required-message">Это обязательный вопрос</div></div>
<!-- Выбор дня -->


<br>
<!-- <p id="date2">Регистрация на 24, 26, 27, 28-е ноября закрыта</p> -->



			<input type="submit" value="Готово" /><br>
			<p>Если вдруг Вам придет более оригинальное название, или изменится количество членов команды, звоните или пишите, не стесняйтесь!</p>
		</fieldset>	
	</form>
</div>
<script>
var team = $("input.team").val();
var quantuty = $("input.quantity").val();
var date = $('input:checked').val();
</script>

<script src="http://ajax.microsoft.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jqModal.min.js"></script>
<script src="js/placeholders.min.js"></script>
<script src="js/engine.js"></script>


</body>
</html>

